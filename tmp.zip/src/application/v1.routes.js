const express = require("express");
const app = express.Router();

//root path (/)
//const matematikaCtrl = require("./controller/matematika");

const bagiMiddleware = (req, res, next) => {
  if (req.queary.angka2 == 0) {
    res.send({ message: "tidak bisa dibagi" });
  } else {
    next();
  }
};
app.get("/", function (req, res) {
  res.send({ message: "hello dari route 1" });
});

const matematikaCtrl = require("./controller/matematika");
app.get("/tambah", matematikaCtrl.tambah);
app.get("/kurang", matematikaCtrl.kurang);
app.get("/kali", matematikaCtrl.kali);
app.get("/bagi", bagiMiddleware, matematikaCtrl.bagi);
module.exports = app;
