function tambah(req, res) {
  const angka1 = parseFloat(req.queary.angka1);
  const angka2 = parseFloat(req.queary.angka2);
  const hasil = angka1 + angka2;
  res.send({ message: `hasil penjumlahan ${hasil}` });
}
module.exports = {
  tambah,
};
