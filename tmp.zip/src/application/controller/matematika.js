function tambah(req, res) {
  const angka1 = parseFloat(req.query.angka1);
  const angka2 = parseFloat(req.query.angka2);
  const hasilTambah = angka1 + angka2;
  res.send({ message: "hasil tambah = " + hasilTambah });
}
function kurang(req, res) {
  const angka1 = parseFloat(req.query.angka1);
  const angka2 = parseFloat(req.query.angka2);
  const hasilKurang = angka1 - angka2;
  res.send({ message: "hasil kurang = " + hasilKurang });
}
function kali(req, res) {
  const angka1 = parseFloat(req.query.angka1);
  const angka2 = parseFloat(req.query.angka2);
  const hasilKali = angka1 * angka2;
  res.send({ message: "hasil Kali = " + hasilKali });
}
function bagi(req, res) {
  const angka1 = parseFloat(req.query.angka1);
  const angka2 = parseFloat(req.query.angka2);
  const hasilBagi = angka1 / angka2;
  res.send({ message: "hasil Bagi = " + hasilBagi });
}

module.exports = {
  tambah,
  kurang,
  kali,
  bagi,
};
